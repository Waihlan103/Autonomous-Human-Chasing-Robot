#include <Arduino.h>
#include <motor_control.hpp>

MotorControl::MotorControl(){
     // Motor pins
     pinMode(MOTOR_A_IN1, OUTPUT);
     pinMode(MOTOR_A_IN2, OUTPUT);
     pinMode(MOTOR_B_IN1, OUTPUT);
     pinMode(MOTOR_B_IN2, OUTPUT);

     // PWM setup
     //ledcSetup(PWM_CH_A1, PWM_FREQ, PWM_RES);
     //ledcSetup(PWM_CH_A2, PWM_FREQ, PWM_RES);
     //ledcSetup(PWM_CH_B1, PWM_FREQ, PWM_RES);
     //ledcSetup(PWM_CH_B2, PWM_FREQ, PWM_RES);

     //ledcAttachPin(MOTOR_A_IN1, PWM_CH_A1);
     //ledcAttachPin(MOTOR_A_IN2, PWM_CH_A2);
     //ledcAttachPin(MOTOR_B_IN1, PWM_CH_B1);
     //ledcAttachPin(MOTOR_B_IN2, PWM_CH_B2);
} 

void MotorControl::move(uint8_t direction, uint8_t left_speed, uint8_t right_speed){
     //if(direction == 'F'){
     //     ledcWrite(PWM_CH_A1, 0);
     //     ledcWrite(PWM_CH_A2, left_speed);
     //     ledcWrite(PWM_CH_B1, right_speed);
     //     ledcWrite(PWM_CH_B2, 0);
     //}
     //else if(direction == 'B'){
     //     ledcWrite(PWM_CH_A1, left_speed);
     //     ledcWrite(PWM_CH_A2, 0);
     //     ledcWrite(PWM_CH_B1, 0);
     //     ledcWrite(PWM_CH_B2, right_speed);
     //}
     //else if(direction == 'L'){
     //     ledcWrite(PWM_CH_A1, 0);
     //     ledcWrite(PWM_CH_A2, left_speed);
     //     ledcWrite(PWM_CH_B1, 0);
     //     ledcWrite(PWM_CH_B2, right_speed);
     //}
     //else if(direction == 'R'){
     //     ledcWrite(PWM_CH_A1, left_speed);
     //     ledcWrite(PWM_CH_A2, 0);
     //     ledcWrite(PWM_CH_B1, right_speed);
     //     ledcWrite(PWM_CH_B2, 0);
     //}
     //else if(direction == 'S'){
     //     ledcWrite(PWM_CH_A1, 0);
     //     ledcWrite(PWM_CH_A2, 0);
     //     ledcWrite(PWM_CH_B1, 0);
     //     ledcWrite(PWM_CH_B2, 0);
     //}
     analogWrite(MOTOR_A_IN1, left_speed * (direction & 0x01) >> 0);
     analogWrite(MOTOR_A_IN2, left_speed * (direction & 0x02) >> 1);
     analogWrite(MOTOR_B_IN1, right_speed * (direction & 0x04) >> 2);
     analogWrite(MOTOR_B_IN2, right_speed * (direction & 0x08) >> 3);
     return;
}

MotorControl::~MotorControl(){
}