#ifndef SERIAL_COMMUNICATION_HPP
#define SERIAL_COMMUNICATION_HPP

#include <motor_control.hpp>
#include <encoder.hpp>
#include <Arduino.h>
#include <PID_control.hpp>

extern uint8_t direction;

extern int LtargetRPM; // Desired RPM
extern int RtargetRPM; // Desired RPM

extern MotorControl motor;

class serialcommunication : public MotorControl
{
private:
    char _serial_read = '\n';

public:
    serialcommunication();
    void operation();
    void move();
    void moveForward();
    void moveBackward();
    void turnLeft();
    void turnRight();
    void stopMoving();
    ~serialcommunication();
};
extern serialcommunication syscom;

#endif